﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "pch.h"
#include "python.h"
#include <cmath>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>


double norm_cdf(double x)
{
    return 0.5 * erfc(-x * sqrt(0.5));
}



double RationalApproximation(double t)
{
    // Abramowitz and Stegun formula 26.2.23.
    // The absolute value of the error should be less than 4.5 e-4.
    double c[] = { 2.515517, 0.802853, 0.010328 };
    double d[] = { 1.432788, 0.189269, 0.001308 };
    return t - ((c[2] * t + c[1]) * t + c[0]) /
        (((d[2] * t + d[1]) * t + d[0]) * t + 1.0);
}

double norm_ppf(double p)
{
    if (p <= 0.0 || p >= 1.0)
    {
        std::stringstream os;
        os << "Invalid input argument (" << p
            << "); must be larger than 0 but less than 1.";
        throw std::invalid_argument(os.str());
    }

    // See article above for explanation of this section.
    if (p < 0.5)
    {
        // F^-1(p) = - G^-1(p)
        return -RationalApproximation(sqrt(-2.0 * log(p)));
    }
    else
    {
        // F^-1(p) = G^-1(1-p)
        return RationalApproximation(sqrt(-2.0 * log(1 - p)));
    }
}


double norm_pdf(double x)
{
    static const double inv_sqrt_2pi = 0.3989422804014327;
    double a = x;

    return inv_sqrt_2pi  * std::exp(-0.5 * a * a);
}

PyObject* MyMath_norm_pdf(PyObject* self, PyObject* args)
{
    double x;
    if (!PyArg_ParseTuple(args, "d", &x))
    {
        return NULL;
    }

    return Py_BuildValue("d", norm_pdf(x));
}

PyObject* MyMath_norm_ppf(PyObject* self, PyObject* args)
{
    double x;
    if (!PyArg_ParseTuple(args, "d", &x))
    {
        return NULL;
    }

    return Py_BuildValue("d", norm_ppf(x));
}

PyObject* MyMath_norm_cdf(PyObject * self, PyObject * args)
{
    double x;
    if (!PyArg_ParseTuple(args, "d", &x))
    {
        return NULL;
    }

    return Py_BuildValue("d", norm_cdf(x));
}


static PyMethodDef MyMath_methods[] = {
    {"norm_cdf", MyMath_norm_cdf, METH_VARARGS, "This is an add function."},
    {"norm_ppf", MyMath_norm_ppf, METH_VARARGS, "This is an add function."},
    {"norm_pdf", MyMath_norm_pdf, METH_VARARGS, "This is an add function."},
    {NULL, NULL, 0, NULL}
};


static PyModuleDef MyMath_module = {
    PyModuleDef_HEAD_INIT,
    "MyMath",
    "My Math Module",
    0,
    MyMath_methods
};

PyMODINIT_FUNC PyInit_MyMath()
{
    return PyModule_Create(&MyMath_module);
}